// Saisir un entier 
Console.WriteLine("Saisi d'un entier : ");
int x = int.Parse(Console.ReadLine());

// Nul; impair ou pair 
bool estNul = (x == 0);
bool estPair = (x % 2 == 0);
bool estImpair = (x % 2 != 0);

//résultats 
Console.WriteLine(x + " est nul ? " + estNul);
Console.WriteLine(x + " est pair ? " + estPair);
Console.WriteLine(x + " est impair ? " + estImpair);