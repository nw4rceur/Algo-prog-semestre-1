
//Les coefficients 

const int coefMaths = 3;
const int coefAlgo = 3;
const int coefPhysique = 2;
const int coefAnglais = 2;
const int coefPix = 1;

// pour le prénom de l'étudiant 
Console.WriteLine( "Donnez le prénom de l'étudiant :");
string prenom = (Console.ReadLine());

// pour la note en maths
Console.WriteLine(" Donnez sa note en Mathématiques :");
int noteMaths = int.Parse(Console.ReadLine());

//pour la note en Algo
Console.WriteLine(" Donnez sa note en Algo-Prog :"); 
int noteAlgo = int.Parse(Console.ReadLine()); 

//pour la note en physique
Console.WriteLine(" Donnez sa note en physique :");
int notePhysique = int.Parse(Console.ReadLine()); 

//pour la note en anglais
Console.WriteLine(" Donnez sa note en anglais :");
int noteAnglais = int.Parse(Console.ReadLine()); 

//pour la note en PIX 
Console.WriteLine(" Donnez sa note en PIX:"); 
int notePix = int.Parse(Console.ReadLine());


//Pour la moyenne 
double moyenne = ( noteMaths * coefMaths + noteAlgo * coefAlgo + notePhysique * coefPhysique + noteAnglais * coefAnglais + notePix * coefPix ) / ( coefAlgo + coefAnglais + coefPhysique + coefPix ) ; 

// bool de validation 
bool semestreOk = moyenne > 10; 

//1f 
Console.WriteLine("L'étudiant " + prenom + " a obtenu une moyenne de : " + moyenne + " ce semestre" );
Console.WriteLine("validation du semestre: " + semestreOk); 

