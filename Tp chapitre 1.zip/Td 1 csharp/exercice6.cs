
const char X = 'X';
const char O = 'O';
const char vide = '.';

char caseL0C0, caseL0C1, caseL0C2 ;
char caseL1C0, caseL1C1, caseL1C2;
char caseL2C0, caseL2C1, caseL2C2;


// pour le prénom du premier joueur
Console.WriteLine( "Donnez le prénom du premier mec");
string joueur1 = (Console.ReadLine()); 

// pour le deuxieme joueur 
Console.WriteLine( "Donnez le prénom du deuixieme mec");
string joueur2 = (Console.ReadLine());

// première ligne

Console.WriteLine( "Saisissez la ligne 0 du plateau avec des X,0 ou . : "); 
string ligne0 = (Console.ReadLine());
caseL0C0 = ligne0[0];
caseL0C1 = ligne0[1];
caseL1C1 = ligne0[2];

// deuxieme ligne
Console.WriteLine( "Saisissez la ligne 1 du plateau avec des X,0 ou . : "); 
string ligne1 = (Console.ReadLine());
caseL1C0 = ligne1[0];
caseL1C1 = ligne1[1];
caseL1C2 = ligne1[2];

// troisieme ligne
Console.WriteLine( "Saisissez la ligne 2 du plateau avec des X,0 ou . : "); 
string ligne2 = (Console.ReadLine());
caseL2C0 = ligne2[0];
caseL2C1 = ligne2[1];
caseL2C2 = ligne2[2];

// Affichge du plateau 
Console.WriteLine( " ------------ " );
Console.WriteLine( $"0  {caseL0C0} | {caseL0C1} | {caseL0C2} " );
Console.WriteLine( " -------------- " );
Console.WriteLine( $"1  {caseL1C0} | {caseL1C1} | {caseL1C2} " );
Console.WriteLine( " -------------- " );
Console.WriteLine( $"2  {caseL2C0} | {caseL2C1} | {caseL2C2} " );
Console.WriteLine( "0     1    2 " );

//qui a gagné?

//vérification pour les lignes 
bool ligne0X = ( caseL0C0 =='X') && ( caseL0C1 == 'X') && (caseL0C2 == 'X');
bool ligne0O = ( caseL0C0 =='O') && ( caseL0C1 == 'O') && (caseL0C2 == 'O');
bool ligne1X = ( caseL0C0 =='X') && ( caseL0C1 == 'X') && (caseL0C2 == 'X');
bool ligne1O = ( caseL0C0 =='O') && ( caseL0C1 == 'O') && (caseL0C2 == 'O');
bool ligne2X = ( caseL0C0 =='X') && ( caseL0C1 == 'X') && (caseL0C2 == 'X');
bool ligne2O = ( caseL0C0 =='O') && ( caseL0C1 == 'O') && (caseL0C2 == 'O');

//vérification pour les colonnes

bool colonne0X = ( caseL0C0 =='X') && ( caseL2C1 == 'X') && (caseL3C1 == 'X');
bool colonne0O = ( caseL0C0 =='O') && ( caseL0C1 == 'O') && (caseL0C2 == 'O');
bool colonne1X = ( caseL0C0 =='X') && ( caseL0C1 == 'X') && (caseL0C2 == 'X');
bool colonne1O = ( caseL0C0 =='O') && ( caseL0C1 == 'O') && (caseL0C2 == 'O');
bool colonne2X = ( caseL0C0 =='X') && ( caseL0C1 == 'X') && (caseL0C2 == 'X');
bool colonne2O = ( caseL0C0 =='O') && ( caseL0C1 == 'O') && (caseL0C2 == 'O');
