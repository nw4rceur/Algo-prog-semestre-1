struct Personne
{
	public string nom;
	public string prenom;
	
	public Personne(string n, string p)
	{
		nom = n;
		prenom = p;
	}
}
// Version 1 => Saisie de nom + prenom et retour d'une Personne
Personne saisiePersonne()
{
	Console.WriteLine("Nom : ");
	string n = Console.ReadLine();
	
	Console.WriteLine("Prenom : ");
	string p = Console.ReadLine();
	
	return new Personne(n,p);
}

//Personne unePersonne = saisiePersonne();
//Console.WriteLine($"Personne cree {unePersonne.nom}, {unePersonne.prenom}");

// Version 2 => Saisie nom, puis saisie prenom dans deux fonctions, puis creation de Personne
string saisirNom()
{
	Console.WriteLine("Nom : ");
	string n = Console.ReadLine();
	return n;
}

string saisirPrenom()
{
	Console.WriteLine("Prenom : ");
	string p = Console.ReadLine();
	return p;
}

Personne unePersonne = new Personne(saisirNom(), saisirPrenom());
Personne uneAutrePersonne = new Personne(saisirNom(), saisirPrenom());
Console.WriteLine($"Nom compose de P1 et P2 {unePersonne.nom + uneAutrePersonne.nom}");