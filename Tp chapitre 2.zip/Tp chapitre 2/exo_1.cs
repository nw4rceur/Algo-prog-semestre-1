// Saisir un entier 
Console.Write("Saisir un entier : ");
int x = int.Parse(Console.ReadLine());

// Méthodes pour chaque booleen

bool EstNul(int x)
{
    return x == 0;
}

bool EstPair(int x)
{
    return x % 2 == 0;
}

bool EstImpair(int x)
{
    return x % 2 != 0;
}

// Résultats
Console.WriteLine($"{x} est nul ? {EstNul(x)}");
Console.WriteLine($"{x} est pair ? {EstPair(x)}");
Console.WriteLine($"{x} est impair ? {EstImpair(x)}");
