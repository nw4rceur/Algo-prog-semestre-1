struct THoraire
{
    public int heure;
    public int minute;
    public int seconde;

    public THoraire(int h, int m, int s)
    {
        heure = h;
        minute = m;
        seconde = s;
    }
}

THoraire saisieHoraire1()
{
    Console.WriteLine("Première heure : ");
    int h = int.Parse(Console.ReadLine());
    Console.WriteLine("Première minute : ");
    int m = int.Parse(Console.ReadLine());
    Console.WriteLine("Première seconde : ");
    int s = int.Parse(Console.ReadLine());

    return new THoraire(h, m, s);
}

THoraire saisieHoraire2()
{
    Console.WriteLine("Deuxième heure : ");
    int h = int.Parse(Console.ReadLine());
    Console.WriteLine("Deuxième minute : ");
    int m = int.Parse(Console.ReadLine());
    Console.WriteLine("Deuxième seconde : ");
    int s = int.Parse(Console.ReadLine());

    return new THoraire(h, m, s);
}

int toSecond(THoraire h)
{
    int toReturn = 0;
    toReturn += h.heure * 3600;
    toReturn += h.minute * 60;
    toReturn += h.seconde;

    return toReturn;
}

THoraire DifferenceHoraires(int h1, int m1, int s1, int h2, int m2, int s2)
{
    // Convertir en secondes
    int totalSeconds1 = h1 * 3600 + m1 * 60 + s1;
    int totalSeconds2 = h2 * 3600 + m2 * 60 + s2;

    // Calculer la différence en secondes (valeur absolue pour éviter négatif)
    int diffSeconds = Math.Abs(totalSeconds2 - totalSeconds1);

    // Reconvertir en heures, minutes, secondes
    int diffH = diffSeconds / 3600;
    int reste = diffSeconds % 3600;
    int diffM = reste / 60;
    int diffS = reste % 60;

    return new THoraire(diffH, diffM, diffS);
}

// Exemple d'utilisation
THoraire h1 = saisieHoraire1();
THoraire h2 = saisieHoraire2();

THoraire diff = DifferenceHoraires(h1.heure, h1.minute, h1.seconde, h2.heure, h2.minute, h2.seconde);
Console.WriteLine($"Différence : {diff.heure} h {diff.minute} m {diff.seconde} s");
