struct Tstudent 
	
	{
		public string Nom; 
		public string Prenom; 
		public double Maths; 
		public double Algo; 
		public double Physique; 
		public double Anglais; 
		public double Pix; 
		
		public tstudent ( string n, string p ) 
		
		{ 
		nom = n; 
		prenom = p; 
		Maths = 0; 
		Algo = 0; 
		Physique = 0;  		
		Anglais = 0; 
		Pix = 0; 
		
		} 

	} 
		
	
struct Tcoeff  

	{ 
		public double MathsCoeff; 
		public double AlgoCoeff; 
		public double PhysiqueCoeff; 
		public double AnglaisCoeff; 
		public double PixCoeff;  
		
		{ 
		public Tcoeff () 
		
		MathsCoeff = 3.0;
		AlgoCoeff = 3.0; 
		PhysiqueCoeff = 2.0; 
		AnglaisCoeff = 2.0; 
		PixCoeff = 1.0; 
		
		} 
		
	} 
	
Tstudent saisieId ()

{ 

	Console.WriteLine( " Nom de l'étudiant : " ); 
	string n = Console.ReadLine(); 
	Console.WriteLine(" Prénom de l'étudiant : " ); 
	string p =  Console.ReadLine(); 
	
	return new Tstudent ( n,p ); 
	
}   

Tstudent saisieNote () 

{ 

	Console.WriteLine( " Note de maths : " );  
	
  