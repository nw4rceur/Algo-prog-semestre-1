

	
		Console.WriteLine( " Ecrire le premier entier" );
		int entier1 = int.Parse(Console.ReadLine()); 
		Console.WriteLine( " Ecrire le deuxième entier entier" );
		int entier2 = int.Parse(Console.ReadLine());
	
 
		
int maximum ( int entier1, int entier2 )
	{
		
		if	( entier1 > entier2 ) 
			
		{ 
		
		Console.WriteLine(" Le maximum entre ses deux entiers est " + entier1 + ".");
		return entier1;

		} 
		
		else
			
		{ 
		Console.WriteLine(" Le maximum entre ses deux entiers est " + entier2 + "."); 
		return entier2; 

		} 
	
	} 

maximum (entier1, entier2); 

	
	
	