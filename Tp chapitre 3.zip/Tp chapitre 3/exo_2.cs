	
// definition des entiers 
		
		Console.WriteLine( " Ecrire le premier entier" );
		int entier1 = int.Parse(Console.ReadLine()); 
		Console.WriteLine( " Ecrire le deuxième entier entier" );
		int entier2 = int.Parse(Console.ReadLine());
		Console.WriteLine( " Ecrire le troisieme entier" );
		int entier3 = int.Parse(Console.ReadLine()); 
		Console.WriteLine( " Ecrire le quatrieme entier entier" );
		int entier4 = int.Parse(Console.ReadLine());
		
// debut des instructions 

		int somme (int entier1, int entier2, int entier3, int entier4)
		
		{
		
		if ( entier1 > 0 && entier2 > 0 && entier3 > 0 && entier4 > 0 )
		
				{ 
				
					int somme = ( entier1 + entier2 + entier3 + entier4); 
					Console.WriteLine( " Tout est ok bro ! " );
					return somme; 
			
				} 
		
		else
				
				{ 
					int somme = 0;
					Console.WriteLine( "Il y'a un entier qui n'est pas positif" );
					return somme; 
				} 
		
		} 
		
somme (entier1, entier2, entier3, entier4); 
		
		


	