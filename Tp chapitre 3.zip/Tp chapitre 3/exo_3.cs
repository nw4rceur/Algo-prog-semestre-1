
// le type enum demandé dans le bonus

	enum Lettre
 
	{
		Minuscule = 'm',
		Majuscule = 'M',
		Erreur = 'F'
	} 
	
//pour que le programme prenne en compte la lettre
	
	Console.WriteLine( " écrit une lettre " ) ; 
	char c = char.Parse(Console.ReadLine());

// la methode pour trouver la lettre 

	char maLettre ( char c )
		
	{
			
			
	if (char.IsLower(c)) // ici on cherche à savoir si le char c est une minuscule

			{
				Console.WriteLine( "minuscule" );
				return 'm';
			}
		
    else if (char.IsUpper(c)) // pareil mais pour la majuscule 
		
			{
				Console.WriteLine( "Majuscule" );
				return 'M';
			}
		
    else
		
			{
				Console.WriteLine(" Erreur "); // le message d'erreur
				return 'F';
			}
	}

maLettre ( c ); 