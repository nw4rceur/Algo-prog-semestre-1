

// le type enum pour faciliter les choses

	enum Signe
 
	{
		Positif = '+',
		Negatif = '-',
		Nul = '0'
	} 
	
// pour lire les deux entiers choisis 

	Console.WriteLine ( " Ecrit le premier entier " ); 
	int entier1 = int.Parse(Console.ReadLine());
	Console.WriteLine ( " Ecrit le second entier " ); 
	int entier2 = int.Parse(Console.ReadLine()); 
	
// La methode principale 

	char signeMultiplication ( int entier1, int entier2 )
	
	{ 
		if ( entier1*entier2 > 0 )
			
			{ 
				Console.WriteLine ( " le signe est postitif (+) " );
				return (char)Signe.Positif;
			} 
		
		else if ( entier1*entier2 < 0 ) 
			
			{ 
				Console.WriteLine ( " le signe est négatif (-) " ); 
				return (char)Signe.Negatif; 
			} 
		else 
			
			{ 
				Console.WriteLine ( " Le résultat est nul (0) " );
				return (char)Signe.Nul; 
				
			} 
	} 
	
signeMultiplication ( entier1, entier2); 