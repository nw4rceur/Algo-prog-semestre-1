
// Pour choisir l'entier requis 
Console.WriteLine( " donne moi un entier positif " ); 
int entier = int.Parse(Console.ReadLine()); 

// Pour initialiser le compteur dont on a besoin pour compter les divisions
int compteur = 0; 


// definition pour le cas 0
if ( entier ==0)
	{
		compteur = 1; 
	} 
	else
	{ 
		while ( entier > 0 ) 
		{ 
			entier = entier / 10; 
			compteur = compteur + 1; 
		} 
	} 

Console.WriteLine(" le nombre d'itérations est de" + compteur);
	