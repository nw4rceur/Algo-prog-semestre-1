

// On demande à l'utilisateur de donner un enetier 

Console.WriteLine ( "Donne moi un entier N");
 
int N = int.Parse(Console.ReadLine()); 
int P = 1; 

	int somme ( int N, int P ) 
	
		{ 
	
		if ( N > P ) // si le nombre choisit est supérieur à l'initialisation de p, cad 1 
		{ 
			P = P + 1;
			int sommeBis = ( N + P ); 
			Console.WriteLine( "Voici le résultat " +  somme ); 
			return sommeBis; 
		}
		
		else // Par contre si le nombre choisit est inférieur à 1 il affiche ce nombre
			
			{ 
				Console.WriteLine( " le résultat est " + N ); 
				return sommeBis; 
			}
		}

// On décide d'utiliser le do while car on sait que la première itération commence à 1 et finit à n
do 
	{ 
		Console.WriteLine(sommeBis); sommeBis = P + 1;
	} 
while ( N <= P ) ; 



			