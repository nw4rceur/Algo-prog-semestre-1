
Console.WriteLine ( " Ecrivez un entier " ); 

int N = int.Parse(Console.ReadLine()); 

for ( int N = 1 ; N <= 12 ; N = N*(N+1) ); 
	{ 
		Console.WriteLine ( N ); 
	}