

// le nombre à trouver
int secret = 13; 

// le champ pour saisir le nombre
Console.WriteLine("Entrez votre nombre"); 
int entier = int.Parse(Console.ReadLine()); 

// le nombre d'essais que l'on doit utiliser à la fin
int essais = 0; 

while ( !entier == secret ) 
	{ 
		Console.WriteLine("Entrez votre nombre"); 
		int entier = int.Parse(Console.ReadLine());
		essais = essais + 1; 
	} 

Console.WriteLine( " le nombre d'essais nécéssaires est de " + essais ); 