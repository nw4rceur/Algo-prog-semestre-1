
// definition du champ nécessaire pour taper le nombre N
Console.WriteLine( "donnez un nombre N" ); 
int N = int.Parse(Console.ReadLine()); 

// Ici on utilise une boucle for parce qu'on connait spécifiquement le nombre de répétitions 
for ( int i = 1; i <= 10; i = i + 1 ) 
	{
		Console.WriteLine( N + " x " + i + " = " + ( N * i )); 
	} 

